import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:_/services/security_service.dart';
import 'package:_/models/message.dart';
import 'package:_/services/storage_service.dart';
import 'package:_/widgets/message_bubble.dart';
import 'package:_/widgets/threat_warning_dialog.dart';

class MessagesScreen extends StatefulWidget {
  const MessagesScreen({super.key});

  @override
  State<MessagesScreen> createState() => _MessagesScreenState();
}

class _MessagesScreenState extends State<MessagesScreen> {
  final TextEditingController _messageController = TextEditingController();
  List<ChatMessage> _messages = [];

  @override
  void initState() {
    super.initState();
    _loadMessages();
    _generateSampleMessages();
  }

  void _loadMessages() {
    setState(() {
      _messages = StorageService.getMessages();
    });
  }

  void _generateSampleMessages() {
    if (_messages.isEmpty) {
      final sampleMessages = [
        ChatMessage(
          id: '1',
          sender: 'أحمد',
          content: 'مرحبا! كيف حالك اليوم؟',
          timestamp: DateTime.now().subtract(const Duration(hours: 2)),
        ),
        ChatMessage(
          id: '2',
          sender: 'سارة',
          content: 'هل تريد اللعب معي؟',
          timestamp: DateTime.now().subtract(const Duration(hours: 1)),
        ),
        ChatMessage(
          id: '3',
          sender: 'مجهول',
          content: 'انقر هنا لتحميل فيروس مجاني وألعاب',
          timestamp: DateTime.now().subtract(const Duration(minutes: 30)),
          containsThreat: true,
          isBlocked: true,
          detectedThreats: ['محتوى ضار محتمل'],
        ),
      ];

      for (final message in sampleMessages) {
        StorageService.saveMessage(message);
      }
      _loadMessages();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('💬 الرسائل'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            color: Theme.of(context).colorScheme.primaryContainer,
            child: Row(
              children: [
                Icon(
                  Icons.info,
                  color: Theme.of(context).colorScheme.primary,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'جميع الرسائل يتم فحصها تلقائياً للحماية من التنمر والمحتوى الضار',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final message = _messages[index];
                return MessageBubble(
                  message: message,
                  onTap: () => _handleMessageTap(message),
                );
              },
            ),
          ),
          _buildMessageInput(),
        ],
      ),
    );
  }

  Widget _buildMessageInput() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        border: Border(
          top: BorderSide(
            color: Theme.of(context).colorScheme.outline.withValues(alpha: 0.2),
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _messageController,
              decoration: InputDecoration(
                hintText: 'اكتب رسالة تجريبية...',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                ),
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          FloatingActionButton.small(
            onPressed: _sendMessage,
            child: Icon(
              Icons.send,
              color: Theme.of(context).colorScheme.onPrimary,
            ),
          ),
        ],
      ),
    );
  }

  void _sendMessage() async {
    final content = _messageController.text.trim();
    if (content.isEmpty) return;

    final message = ChatMessage(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      sender: 'أنت',
      content: content,
      timestamp: DateTime.now(),
    );

    _messageController.clear();

    // Scan message for threats
    final securityService = Provider.of<SecurityService>(context, listen: false);
    final threat = await securityService.scanMessage(message);

    if (threat != null) {
      // Show warning dialog
      if (mounted) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (context) => ThreatWarningDialog(threat: threat),
        );
      }
      
      // Save blocked message
      final blockedMessage = ChatMessage(
        id: message.id,
        sender: message.sender,
        content: message.content,
        timestamp: message.timestamp,
        isBlocked: true,
        containsThreat: true,
        detectedThreats: [threat.description],
      );
      
      await StorageService.saveMessage(blockedMessage);
    } else {
      // Save safe message
      await StorageService.saveMessage(message);
    }

    _loadMessages();
  }

  void _handleMessageTap(ChatMessage message) {
    if (message.isBlocked) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('⚠️ رسالة محظورة'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('هذه الرسالة تم حظرها لحمايتك من:'),
              const SizedBox(height: 8),
              ...message.detectedThreats.map((threat) => 
                Text('• $threat', style: const TextStyle(fontWeight: FontWeight.bold))
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('فهمت'),
            ),
          ],
        ),
      );
    }
  }
}