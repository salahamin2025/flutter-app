import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:_/services/notification_service.dart';
import 'package:_/services/storage_service.dart';
import 'package:_/models/threat_detection.dart';
import 'package:_/widgets/threat_warning_dialog.dart';

class AlertsScreen extends StatefulWidget {
  const AlertsScreen({super.key});

  @override
  State<AlertsScreen> createState() => _AlertsScreenState();
}

class _AlertsScreenState extends State<AlertsScreen> with TickerProviderStateMixin {
  late TabController _tabController;
  List<ThreatDetection> _threats = [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadThreats();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _loadThreats() {
    setState(() {
      _threats = StorageService.getThreatHistory();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('🚨 التنبيهات'),
        centerTitle: true,
        bottom: TabBar(
          controller: _tabController,
          labelColor: Theme.of(context).colorScheme.primary,
          unselectedLabelColor: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.6),
          indicatorColor: Theme.of(context).colorScheme.primary,
          tabs: [
            Tab(
              icon: Icon(
                Icons.security,
                color: Theme.of(context).colorScheme.primary,
              ),
              text: 'سجل التهديدات',
            ),
            Tab(
              icon: Icon(
                Icons.notification_important,
                color: Theme.of(context).colorScheme.primary,
              ),
              text: 'تنبيهات الوالدين',
            ),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildThreatsTab(),
          _buildParentNotificationsTab(),
        ],
      ),
    );
  }

  Widget _buildThreatsTab() {
    if (_threats.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.shield_outlined,
              size: 64,
              color: Theme.of(context).colorScheme.primary,
            ),
            const SizedBox(height: 16),
            Text(
              '🎉 لا توجد تهديدات',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'رائع! جهازك محمي بالكامل',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
              ),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _threats.length,
      itemBuilder: (context, index) {
        final threat = _threats[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: ListTile(
            leading: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: threat.severityColor.withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                _getThreatIcon(threat.type),
                color: threat.severityColor,
              ),
            ),
            title: Text(
              threat.typeDisplayName,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(threat.description),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: threat.severityColor,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        threat.severityDisplayName,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      _formatDateTime(threat.timestamp),
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.6),
                      ),
                    ),
                  ],
                ),
              ],
            ),
            trailing: threat.wasBlocked 
              ? Icon(
                  Icons.block,
                  color: Theme.of(context).colorScheme.error,
                )
              : Icon(
                  Icons.warning,
                  color: Theme.of(context).colorScheme.tertiary,
                ),
          ),
        );
      },
    );
  }

  Widget _buildParentNotificationsTab() {
    return Consumer<NotificationService>(
      builder: (context, notificationService, child) {
        final notifications = notificationService.notifications;
        
        if (notifications.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.mail_outline,
                  size: 64,
                  color: Theme.of(context).colorScheme.primary,
                ),
                const SizedBox(height: 16),
                Text(
                  'لا توجد تنبيهات',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'لم يتم إرسال أي تنبيهات للوالدين بعد',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
                  ),
                ),
              ],
            ),
          );
        }

        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: notifications.length,
          itemBuilder: (context, index) {
            final notification = notifications[index];
            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              color: Theme.of(context).colorScheme.tertiaryContainer,
              child: ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.tertiary,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    Icons.send,
                    color: Theme.of(context).colorScheme.onTertiary,
                  ),
                ),
                title: Text(
                  'تنبيه للوالدين',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(notification.message),
                    const SizedBox(height: 4),
                    Text(
                      'تم الإرسال: ${_formatDateTime(notification.sentAt)}',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.6),
                      ),
                    ),
                  ],
                ),
                trailing: Icon(
                  Icons.email,
                  color: Theme.of(context).colorScheme.tertiary,
                ),
              ),
            );
          },
        );
      },
    );
  }


  Future<void> _openSafeUrl(String url) async {
    try {
      final uri = Uri.parse(url);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('خطأ في فتح الرابط')),
        );
      }
    }
  }

  IconData _getThreatIcon(ThreatType type) {
    switch (type) {
      case ThreatType.cyberbullying:
        return Icons.person_off;
      case ThreatType.maliciousMessage:
        return Icons.message_outlined;
      case ThreatType.maliciousWebsite:
        return Icons.web;
      case ThreatType.suspiciousLink:
        return Icons.link;
      case ThreatType.inappropriateContent:
        return Icons.block;
    }
  }

  String _getWebsiteName(String url) {
    final uri = Uri.parse(url);
    return uri.host.replaceAll('www.', '').split('.').first;
  }

  String _formatDateTime(DateTime dateTime) {
    return '${dateTime.day}/${dateTime.month} ${dateTime.hour}:${dateTime.minute.toString().padLeft(2, '0')}';
  }
}