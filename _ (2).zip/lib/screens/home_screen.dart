import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:_/services/security_service.dart';
import 'package:_/services/notification_service.dart';
import 'package:_/services/storage_service.dart';
import 'package:_/screens/messages_screen.dart';
import 'package:_/screens/browser_screen.dart';
import 'package:_/screens/alerts_screen.dart';
import 'package:_/screens/settings_screen.dart';
import 'package:_/widgets/protection_status_card.dart';
import 'package:_/widgets/quick_stats_card.dart';
import 'package:_/widgets/feature_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: CustomScrollView(
            slivers: [
              SliverAppBar(
                expandedHeight: 120,
                floating: true,
                pinned: true,
                flexibleSpace: FlexibleSpaceBar(
                  title: Text(
                    '🛡️ الحارس الصغير',
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      color: Theme.of(context).colorScheme.onPrimaryContainer,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  centerTitle: true,
                ),
                actions: [
                  Consumer<NotificationService>(
                    builder: (context, notificationService, child) {
                      return Stack(
                        children: [
                          IconButton(
                            icon: Icon(
                              Icons.notifications,
                              color: Theme.of(context).colorScheme.onPrimaryContainer,
                            ),
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => const AlertsScreen()),
                              );
                            },
                          ),
                          if (notificationService.unreadCount > 0)
                            Positioned(
                              right: 8,
                              top: 8,
                              child: Container(
                                padding: const EdgeInsets.all(4),
                                decoration: BoxDecoration(
                                  color: Theme.of(context).colorScheme.error,
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Text(
                                  '${notificationService.unreadCount}',
                                  style: TextStyle(
                                    color: Theme.of(context).colorScheme.onError,
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                        ],
                      );
                    },
                  ),
                ],
              ),
              SliverPadding(
                padding: const EdgeInsets.all(16),
                sliver: SliverList(
                  delegate: SliverChildListDelegate([
                    const ProtectionStatusCard(),
                    const SizedBox(height: 16),
                    const QuickStatsCard(),
                    const SizedBox(height: 24),
                    Text(
                      '🔒 الميزات الذكية',
                      style: Theme.of(context).textTheme.headlineSmall,
                    ),
                    const SizedBox(height: 16),
                    _buildFeatureGrid(context),
                    const SizedBox(height: 24),
                    _buildQuickTips(context),
                  ]),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFeatureGrid(BuildContext context) {
    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      mainAxisSpacing: 16,
      crossAxisSpacing: 16,
      childAspectRatio: 1.1,
      children: [
        FeatureCard(
          icon: Icons.message_rounded,
          title: 'فحص الرسائل',
          subtitle: 'حماية من التنمر',
          color: Theme.of(context).colorScheme.secondary,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const MessagesScreen()),
          ),
        ),
        FeatureCard(
          icon: Icons.web,
          title: 'التصفح الآمن',
          subtitle: 'حماية من المواقع الضارة',
          color: Theme.of(context).colorScheme.tertiary,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const BrowserScreen()),
          ),
        ),
        FeatureCard(
          icon: Icons.history,
          title: 'سجل النشاط',
          subtitle: 'مراجعة التهديدات',
          color: Theme.of(context).colorScheme.primary,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const AlertsScreen()),
          ),
        ),
        FeatureCard(
          icon: Icons.settings,
          title: 'الإعدادات',
          subtitle: 'تخصيص الحماية',
          color: Colors.purple,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const SettingsScreen()),
          ),
        ),
      ],
    );
  }

  Widget _buildQuickTips(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.lightbulb,
                  color: Theme.of(context).colorScheme.tertiary,
                ),
                const SizedBox(width: 8),
                Text(
                  'نصائح للأمان',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            _buildTipItem('لا تشارك معلوماتك الشخصية مع الغرباء'),
            _buildTipItem('أخبر والديك عند تلقي رسائل غريبة'),
            _buildTipItem('لا تنقر على روابط من مصادر غير موثوقة'),
          ],
        ),
      ),
    );
  }

  Widget _buildTipItem(String tip) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            Icons.check_circle,
            size: 16,
            color: Theme.of(context).colorScheme.primary,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              tip,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ),
        ],
      ),
    );
  }
}