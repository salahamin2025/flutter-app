import 'package:flutter/material.dart';
import 'package:_/models/app_settings.dart';
import 'package:_/services/storage_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late AppSettings _settings;
  final _parentEmailController = TextEditingController();
  final _parentPhoneController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _settings = StorageService.getSettings();
    _parentEmailController.text = _settings.parentEmail;
    _parentPhoneController.text = _settings.parentPhone;
  }

  @override
  void dispose() {
    _parentEmailController.dispose();
    _parentPhoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('⚙️ الإعدادات'),
        centerTitle: true,
        actions: [
          TextButton(
            onPressed: _saveSettings,
            child: Text(
              'حفظ',
              style: TextStyle(
                color: Theme.of(context).colorScheme.primary,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildParentInfoSection(),
            const SizedBox(height: 24),
            _buildProtectionSettingsSection(),
            const SizedBox(height: 24),
            _buildNotificationSettingsSection(),
            const SizedBox(height: 24),
            _buildProtectionLevelSection(),
            const SizedBox(height: 24),
            _buildDangerZoneSection(),
          ],
        ),
      ),
    );
  }

  Widget _buildParentInfoSection() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.family_restroom,
                  color: Theme.of(context).colorScheme.primary,
                ),
                const SizedBox(width: 8),
                Text(
                  'معلومات الوالدين',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _parentEmailController,
              decoration: const InputDecoration(
                labelText: 'البريد الإلكتروني للوالدين',
                hintText: 'parent@example.com',
                prefixIcon: Icon(Icons.email),
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.emailAddress,
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _parentPhoneController,
              decoration: const InputDecoration(
                labelText: 'رقم هاتف الوالدين',
                hintText: '+966 50 123 4567',
                prefixIcon: Icon(Icons.phone),
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.phone,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProtectionSettingsSection() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.shield,
                  color: Theme.of(context).colorScheme.secondary,
                ),
                const SizedBox(width: 8),
                Text(
                  'إعدادات الحماية',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            SwitchListTile(
              title: const Text('فحص الرسائل'),
              subtitle: const Text('كشف التنمر والمحتوى الضار'),
              value: _settings.enableMessageScanning,
              onChanged: (value) {
                setState(() {
                  _settings = _settings.copyWith(enableMessageScanning: value);
                });
              },
              secondary: Icon(
                Icons.message,
                color: Theme.of(context).colorScheme.secondary,
              ),
            ),
            SwitchListTile(
              title: const Text('حماية المواقع'),
              subtitle: const Text('فحص المواقع باستخدام VirusTotal'),
              value: _settings.enableWebsiteProtection,
              onChanged: (value) {
                setState(() {
                  _settings = _settings.copyWith(enableWebsiteProtection: value);
                });
              },
              secondary: Icon(
                Icons.web,
                color: Theme.of(context).colorScheme.secondary,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNotificationSettingsSection() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.notifications,
                  color: Theme.of(context).colorScheme.tertiary,
                ),
                const SizedBox(width: 8),
                Text(
                  'إعدادات التنبيهات',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            SwitchListTile(
              title: const Text('التنبيهات الصوتية'),
              subtitle: const Text('تشغيل صوت تحذيري عند اكتشاف تهديد'),
              value: _settings.enableAudioAlerts,
              onChanged: (value) {
                setState(() {
                  _settings = _settings.copyWith(enableAudioAlerts: value);
                });
              },
              secondary: Icon(
                Icons.volume_up,
                color: Theme.of(context).colorScheme.tertiary,
              ),
            ),
            SwitchListTile(
              title: const Text('تنبيهات الوالدين'),
              subtitle: const Text('إرسال إشعارات للوالدين عند اكتشاف تهديد'),
              value: _settings.enableParentNotifications,
              onChanged: (value) {
                setState(() {
                  _settings = _settings.copyWith(enableParentNotifications: value);
                });
              },
              secondary: Icon(
                Icons.mail,
                color: Theme.of(context).colorScheme.tertiary,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProtectionLevelSection() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.security_outlined,
                  color: Theme.of(context).colorScheme.primary,
                ),
                const SizedBox(width: 8),
                Text(
                  'مستوى الحماية',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Text(
              'المستوى الحالي: ${_settings.protectionLevelName}',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
            const SizedBox(height: 12),
            Slider(
              value: _settings.protectionLevel.toDouble(),
              min: 1,
              max: 3,
              divisions: 2,
              label: _settings.protectionLevelName,
              onChanged: (value) {
                setState(() {
                  _settings = _settings.copyWith(protectionLevel: value.round());
                });
              },
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'منخفض',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                Text(
                  'متوسط',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                Text(
                  'عالي',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDangerZoneSection() {
    return Card(
      color: Theme.of(context).colorScheme.errorContainer.withValues(alpha: 0.3),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.warning,
                  color: Theme.of(context).colorScheme.error,
                ),
                const SizedBox(width: 8),
                Text(
                  'منطقة خطر',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: Theme.of(context).colorScheme.error,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: _clearAllData,
                icon: Icon(
                  Icons.delete_forever,
                  color: Theme.of(context).colorScheme.error,
                ),
                label: Text(
                  'مسح جميع البيانات',
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.error,
                  ),
                ),
                style: OutlinedButton.styleFrom(
                  side: BorderSide(color: Theme.of(context).colorScheme.error),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _saveSettings() async {
    final updatedSettings = _settings.copyWith(
      parentEmail: _parentEmailController.text,
      parentPhone: _parentPhoneController.text,
    );
    
    await StorageService.saveSettings(updatedSettings);
    
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('تم حفظ الإعدادات بنجاح'),
          backgroundColor: Theme.of(context).colorScheme.primary,
        ),
      );
    }
  }

  void _clearAllData() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('⚠️ تأكيد المسح'),
        content: const Text(
          'هل أنت متأكد من مسح جميع البيانات؟ لن يمكن استرجاعها.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () async {
              await StorageService.prefs.clear();
              Navigator.pop(context);
              Navigator.pop(context);
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('تم مسح جميع البيانات')),
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.error,
              foregroundColor: Theme.of(context).colorScheme.onError,
            ),
            child: const Text('مسح'),
          ),
        ],
      ),
    );
  }
}