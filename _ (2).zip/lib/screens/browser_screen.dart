import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:_/services/security_service.dart';
import 'package:_/widgets/threat_warning_dialog.dart';

class BrowserScreen extends StatefulWidget {
  const BrowserScreen({super.key});

  @override
  State<BrowserScreen> createState() => _BrowserScreenState();
}

class _BrowserScreenState extends State<BrowserScreen> {
  final TextEditingController _urlController = TextEditingController();
  bool _isLoading = false;
  String? _lastScannedUrl;

  final List<String> _safeWebsites = [
    'https://www.google.com',
    'https://www.youtube.com/kids',
    'https://www.kidssearch.com',
    'https://www.funbrain.com',
    'https://www.nasa.gov/kids',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('🌐 التصفح الآمن'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            color: Theme.of(context).colorScheme.primaryContainer,
            child: Row(
              children: [
                Icon(
                  Icons.security,
                  color: Theme.of(context).colorScheme.primary,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'جميع المواقع يتم فحصها باستخدام VirusTotal للحماية',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                _buildUrlInput(),
                const SizedBox(height: 24),
                _buildSafeWebsites(),
              ],
            ),
          ),
          Expanded(
            child: _buildTestUrls(),
          ),
        ],
      ),
    );
  }

  Widget _buildUrlInput() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'أدخل رابط الموقع:',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _urlController,
                decoration: InputDecoration(
                  hintText: 'https://example.com',
                  prefixIcon: const Icon(Icons.language),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                onSubmitted: (value) => _scanAndOpenUrl(value),
              ),
            ),
            const SizedBox(width: 8),
            ElevatedButton(
              onPressed: _isLoading ? null : () => _scanAndOpenUrl(_urlController.text),
              style: ElevatedButton.styleFrom(
                backgroundColor: Theme.of(context).colorScheme.primary,
                foregroundColor: Theme.of(context).colorScheme.onPrimary,
                padding: const EdgeInsets.all(16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: _isLoading 
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.search),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildSafeWebsites() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '✅ مواقع آمنة للأطفال:',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.bold,
            color: Theme.of(context).colorScheme.primary,
          ),
        ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: _safeWebsites.map((url) => 
            ActionChip(
              label: Text(
                _getWebsiteName(url),
                style: TextStyle(
                  color: Theme.of(context).colorScheme.onSecondary,
                ),
              ),
              backgroundColor: Theme.of(context).colorScheme.secondary,
              onPressed: () => _openSafeUrl(url),
            )
          ).toList(),
        ),
      ],
    );
  }

  Widget _buildTestUrls() {
    final securityService = Provider.of<SecurityService>(context);
    final testUrls = securityService.getSampleUrls();
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Text(
            '🧪 اختبار الحماية:',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: testUrls.length,
            itemBuilder: (context, index) {
              final url = testUrls[index];
              final isSafe = url.contains('google.com') || url.contains('youtube.com');
              
              return Card(
                margin: const EdgeInsets.only(bottom: 8),
                child: ListTile(
                  leading: Icon(
                    isSafe ? Icons.verified_user : Icons.dangerous,
                    color: isSafe 
                      ? Theme.of(context).colorScheme.primary
                      : Theme.of(context).colorScheme.error,
                  ),
                  title: Text(
                    url,
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  subtitle: Text(
                    isSafe ? 'موقع آمن' : 'موقع خطير - سيتم حظره',
                    style: TextStyle(
                      color: isSafe 
                        ? Theme.of(context).colorScheme.primary
                        : Theme.of(context).colorScheme.error,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  trailing: Icon(
                    Icons.open_in_new,
                    color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.5),
                  ),
                  onTap: () => _scanAndOpenUrl(url),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Future<void> _scanAndOpenUrl(String url) async {
    if (url.trim().isEmpty) return;

    setState(() {
      _isLoading = true;
      _lastScannedUrl = url;
    });

    final securityService = Provider.of<SecurityService>(context, listen: false);
    final threat = await securityService.scanWebsite(url);

    setState(() {
      _isLoading = false;
    });

    if (threat != null) {
      // Show threat warning
      if (mounted) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (context) => ThreatWarningDialog(threat: threat),
        );
      }
    } else {
      // Safe to open
      _showSuccessAndOpen(url);
    }
  }

  void _showSuccessAndOpen(String url) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('✅ موقع آمن'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.verified_user,
              size: 64,
              color: Theme.of(context).colorScheme.primary,
            ),
            const SizedBox(height: 16),
            Text(
              'هذا الموقع آمن ويمكن زيارته',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              url,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _openSafeUrl(url);
            },
            child: const Text('فتح الموقع'),
          ),
        ],
      ),
    );
  }

  Future<void> _openSafeUrl(String url) async {
    try {
      final uri = Uri.parse(url);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('خطأ في فتح الرابط')),
        );
      }
    }
  }

  String _getWebsiteName(String url) {
    final uri = Uri.parse(url);
    return uri.host.replaceAll('www.', '');
  }
}