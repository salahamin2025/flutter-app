import 'package:flutter/material.dart';
import 'package:_/models/message.dart';

class MessageBubble extends StatelessWidget {
  final ChatMessage message;
  final VoidCallback? onTap;

  const MessageBubble({
    super.key,
    required this.message,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isOwn = message.sender == 'أنت';
    
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: isOwn ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          if (!isOwn) ...[
            CircleAvatar(
              radius: 16,
              backgroundColor: Theme.of(context).colorScheme.secondary,
              child: Text(
                message.sender.substring(0, 1),
                style: TextStyle(
                  color: Theme.of(context).colorScheme.onSecondary,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: GestureDetector(
              onTap: onTap,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  color: _getBubbleColor(context, isOwn),
                  borderRadius: BorderRadius.circular(18).copyWith(
                    bottomLeft: isOwn ? const Radius.circular(18) : const Radius.circular(4),
                    bottomRight: isOwn ? const Radius.circular(4) : const Radius.circular(18),
                  ),
                  border: message.isBlocked ? Border.all(
                    color: Theme.of(context).colorScheme.error,
                    width: 2,
                  ) : null,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (!isOwn)
                      Text(
                        message.sender,
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                      ),
                    if (message.isBlocked) ...[
                      Row(
                        children: [
                          Icon(
                            Icons.block,
                            size: 16,
                            color: Theme.of(context).colorScheme.error,
                          ),
                          const SizedBox(width: 4),
                          Expanded(
                            child: Text(
                              'رسالة محظورة',
                              style: TextStyle(
                                color: Theme.of(context).colorScheme.error,
                                fontWeight: FontWeight.bold,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.errorContainer,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          'محتوى مخفي للحماية',
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.onErrorContainer,
                            fontStyle: FontStyle.italic,
                          ),
                        ),
                      ),
                    ] else
                      Text(
                        message.content,
                        style: TextStyle(
                          color: _getTextColor(context, isOwn),
                        ),
                      ),
                    const SizedBox(height: 4),
                    Text(
                      _formatTime(message.timestamp),
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: _getTextColor(context, isOwn).withValues(alpha: 0.6),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          if (isOwn) ...[
            const SizedBox(width: 8),
            CircleAvatar(
              radius: 16,
              backgroundColor: Theme.of(context).colorScheme.primary,
              child: Icon(
                Icons.person,
                size: 16,
                color: Theme.of(context).colorScheme.onPrimary,
              ),
            ),
          ],
        ],
      ),
    );
  }

  Color _getBubbleColor(BuildContext context, bool isOwn) {
    if (message.isBlocked) {
      return Theme.of(context).colorScheme.errorContainer.withValues(alpha: 0.3);
    }
    return isOwn
        ? Theme.of(context).colorScheme.primary
        : Theme.of(context).colorScheme.surface;
  }

  Color _getTextColor(BuildContext context, bool isOwn) {
    if (message.isBlocked) {
      return Theme.of(context).colorScheme.onErrorContainer;
    }
    return isOwn
        ? Theme.of(context).colorScheme.onPrimary
        : Theme.of(context).colorScheme.onSurface;
  }

  String _formatTime(DateTime timestamp) {
    final now = DateTime.now();
    final diff = now.difference(timestamp);

    if (diff.inMinutes < 60) {
      return 'منذ ${diff.inMinutes} دقيقة';
    } else if (diff.inHours < 24) {
      return 'منذ ${diff.inHours} ساعة';
    } else {
      return '${timestamp.day}/${timestamp.month}';
    }
  }
}