class ChatMessage {
  final String id;
  final String sender;
  final String content;
  final DateTime timestamp;
  final bool isBlocked;
  final bool containsThreat;
  final List<String> detectedThreats;

  ChatMessage({
    required this.id,
    required this.sender,
    required this.content,
    required this.timestamp,
    this.isBlocked = false,
    this.containsThreat = false,
    this.detectedThreats = const [],
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'sender': sender,
    'content': content,
    'timestamp': timestamp.millisecondsSinceEpoch,
    'isBlocked': isBlocked,
    'containsThreat': containsThreat,
    'detectedThreats': detectedThreats,
  };

  factory ChatMessage.fromJson(Map<String, dynamic> json) => ChatMessage(
    id: json['id'],
    sender: json['sender'],
    content: json['content'],
    timestamp: DateTime.fromMillisecondsSinceEpoch(json['timestamp']),
    isBlocked: json['isBlocked'] ?? false,
    containsThreat: json['containsThreat'] ?? false,
    detectedThreats: List<String>.from(json['detectedThreats'] ?? []),
  );
}