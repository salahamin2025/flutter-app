import 'package:flutter/material.dart';

enum ThreatType {
  maliciousMessage,
  cyberbullying,
  maliciousWebsite,
  suspiciousLink,
  inappropriateContent,
}

enum ThreatSeverity {
  low,
  medium,
  high,
  critical,
}

class ThreatDetection {
  final String id;
  final ThreatType type;
  final ThreatSeverity severity;
  final String content;
  final String source;
  final DateTime timestamp;
  final bool wasBlocked;
  final String description;

  ThreatDetection({
    required this.id,
    required this.type,
    required this.severity,
    required this.content,
    required this.source,
    required this.timestamp,
    required this.wasBlocked,
    required this.description,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'type': type.index,
    'severity': severity.index,
    'content': content,
    'source': source,
    'timestamp': timestamp.millisecondsSinceEpoch,
    'wasBlocked': wasBlocked,
    'description': description,
  };

  factory ThreatDetection.fromJson(Map<String, dynamic> json) => ThreatDetection(
    id: json['id'],
    type: ThreatType.values[json['type']],
    severity: ThreatSeverity.values[json['severity']],
    content: json['content'],
    source: json['source'],
    timestamp: DateTime.fromMillisecondsSinceEpoch(json['timestamp']),
    wasBlocked: json['wasBlocked'],
    description: json['description'],
  );

  String get typeDisplayName {
    switch (type) {
      case ThreatType.maliciousMessage:
        return 'رسالة ضارة';
      case ThreatType.cyberbullying:
        return 'تنمر إلكتروني';
      case ThreatType.maliciousWebsite:
        return 'موقع ضار';
      case ThreatType.suspiciousLink:
        return 'رابط مشبوه';
      case ThreatType.inappropriateContent:
        return 'محتوى غير مناسب';
    }
  }

  String get severityDisplayName {
    switch (severity) {
      case ThreatSeverity.low:
        return 'منخفض';
      case ThreatSeverity.medium:
        return 'متوسط';
      case ThreatSeverity.high:
        return 'عالي';
      case ThreatSeverity.critical:
        return 'حرج';
    }
  }

  Color get severityColor {
    switch (severity) {
      case ThreatSeverity.low:
        return const Color(0xFF4CAF50);
      case ThreatSeverity.medium:
        return const Color(0xFFFF9800);
      case ThreatSeverity.high:
        return const Color(0xFFFF5722);
      case ThreatSeverity.critical:
        return const Color(0xFFF44336);
    }
  }
}