class AppSettings {
  final String parentEmail;
  final String parentPhone;
  final bool enableMessageScanning;
  final bool enableWebsiteProtection;
  final bool enableAudioAlerts;
  final bool enableParentNotifications;
  final int protectionLevel; // 1-3 (low, medium, high)

  AppSettings({
    this.parentEmail = '',
    this.parentPhone = '',
    this.enableMessageScanning = true,
    this.enableWebsiteProtection = true,
    this.enableAudioAlerts = true,
    this.enableParentNotifications = true,
    this.protectionLevel = 2,
  });

  Map<String, dynamic> toJson() => {
    'parentEmail': parentEmail,
    'parentPhone': parentPhone,
    'enableMessageScanning': enableMessageScanning,
    'enableWebsiteProtection': enableWebsiteProtection,
    'enableAudioAlerts': enableAudioAlerts,
    'enableParentNotifications': enableParentNotifications,
    'protectionLevel': protectionLevel,
  };

  factory AppSettings.fromJson(Map<String, dynamic> json) => AppSettings(
    parentEmail: json['parentEmail'] ?? '',
    parentPhone: json['parentPhone'] ?? '',
    enableMessageScanning: json['enableMessageScanning'] ?? true,
    enableWebsiteProtection: json['enableWebsiteProtection'] ?? true,
    enableAudioAlerts: json['enableAudioAlerts'] ?? true,
    enableParentNotifications: json['enableParentNotifications'] ?? true,
    protectionLevel: json['protectionLevel'] ?? 2,
  );

  AppSettings copyWith({
    String? parentEmail,
    String? parentPhone,
    bool? enableMessageScanning,
    bool? enableWebsiteProtection,
    bool? enableAudioAlerts,
    bool? enableParentNotifications,
    int? protectionLevel,
  }) => AppSettings(
    parentEmail: parentEmail ?? this.parentEmail,
    parentPhone: parentPhone ?? this.parentPhone,
    enableMessageScanning: enableMessageScanning ?? this.enableMessageScanning,
    enableWebsiteProtection: enableWebsiteProtection ?? this.enableWebsiteProtection,
    enableAudioAlerts: enableAudioAlerts ?? this.enableAudioAlerts,
    enableParentNotifications: enableParentNotifications ?? this.enableParentNotifications,
    protectionLevel: protectionLevel ?? this.protectionLevel,
  );

  String get protectionLevelName {
    switch (protectionLevel) {
      case 1:
        return 'منخفض';
      case 2:
        return 'متوسط';
      case 3:
        return 'عالي';
      default:
        return 'متوسط';
    }
  }
}