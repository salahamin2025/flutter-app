import 'dart:math';
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:_/models/threat_detection.dart';
import 'package:_/models/message.dart';
import 'package:_/services/storage_service.dart';
import 'package:_/services/notification_service.dart';

class SecurityService extends ChangeNotifier {
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isScanning = false;
  
  // Simulated threat keywords for detection
  final List<String> _bullyingKeywords = [
    'غبي', 'احمق', 'قبيح', 'وحش', 'كريه', 'مقزز',
    'stupid', 'ugly', 'hate', 'idiot', 'loser', 'freak'
  ];
  
  final List<String> _maliciousKeywords = [
    'فيروس', 'هاك', 'كلمة سر', 'حساب بنكي', 'معلومات شخصية',
    'virus', 'hack', 'password', 'credit card', 'personal info', 'download'
  ];

  final List<String> _maliciousDomains = [
    'malware-site.com',
    'phishing-bank.net',
    'fake-download.org',
    'virus-infected.com',
    'suspicious-link.net'
  ];

  bool get isScanning => _isScanning;

  Future<ThreatDetection?> scanMessage(ChatMessage message) async {
    _isScanning = true;
    notifyListeners();

    // Simulate scanning delay
    await Future.delayed(const Duration(milliseconds: 800));

    ThreatDetection? threat;
    
    // Check for cyberbullying
    if (_containsBullying(message.content)) {
      threat = ThreatDetection(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        type: ThreatType.cyberbullying,
        severity: ThreatSeverity.high,
        content: message.content,
        source: message.sender,
        timestamp: DateTime.now(),
        wasBlocked: true,
        description: 'تم اكتشاف محتوى تنمر في الرسالة',
      );
    }
    // Check for malicious content
    else if (_containsMaliciousContent(message.content)) {
      threat = ThreatDetection(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        type: ThreatType.maliciousMessage,
        severity: ThreatSeverity.medium,
        content: message.content,
        source: message.sender,
        timestamp: DateTime.now(),
        wasBlocked: true,
        description: 'تم اكتشاف محتوى ضار محتمل في الرسالة',
      );
    }

    if (threat != null) {
      await _handleThreatDetected(threat);
    }

    _isScanning = false;
    notifyListeners();
    return threat;
  }

  Future<ThreatDetection?> scanWebsite(String url) async {
    _isScanning = true;
    notifyListeners();

    // Simulate VirusTotal API call
    await Future.delayed(const Duration(milliseconds: 1200));

    ThreatDetection? threat;
    
    if (_isMaliciousDomain(url)) {
      threat = ThreatDetection(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        type: ThreatType.maliciousWebsite,
        severity: ThreatSeverity.critical,
        content: url,
        source: 'VirusTotal Scan',
        timestamp: DateTime.now(),
        wasBlocked: true,
        description: 'تم اكتشاف موقع ضار - محظور للحماية',
      );
    }
    // Random chance for suspicious websites (demo purposes)
    else if (Random().nextDouble() < 0.3) {
      threat = ThreatDetection(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        type: ThreatType.suspiciousLink,
        severity: ThreatSeverity.medium,
        content: url,
        source: 'VirusTotal Scan',
        timestamp: DateTime.now(),
        wasBlocked: true,
        description: 'موقع مشبوه - تم حظره احترازياً',
      );
    }

    if (threat != null) {
      await _handleThreatDetected(threat);
    }

    _isScanning = false;
    notifyListeners();
    return threat;
  }

  bool _containsBullying(String content) {
    final lowerContent = content.toLowerCase();
    return _bullyingKeywords.any((keyword) => lowerContent.contains(keyword.toLowerCase()));
  }

  bool _containsMaliciousContent(String content) {
    final lowerContent = content.toLowerCase();
    return _maliciousKeywords.any((keyword) => lowerContent.contains(keyword.toLowerCase()));
  }

  bool _isMaliciousDomain(String url) {
    return _maliciousDomains.any((domain) => url.contains(domain));
  }

  Future<void> _handleThreatDetected(ThreatDetection threat) async {
    // Save threat to storage
    await StorageService.saveThreatDetection(threat);
    await StorageService.incrementThreatCount();

    // Play warning sound
    await _playWarningSound();

    // Notify parents
    final notificationService = NotificationService();
    notificationService.sendParentAlert(threat);
  }

  Future<void> _playWarningSound() async {
    try {
      // For demo, we'll use a system sound
      // In a real app, you'd include actual audio files
      await _audioPlayer.play(AssetSource('sounds/warning.mp3'));
    } catch (e) {
      // Fallback - no audio if file not found
      debugPrint('Warning sound not available: $e');
    }
  }

  List<String> getSampleThreats() {
    return [
      'أنت غبي جداً ولا أحد يحبك', // Bullying
      'انقر هنا لتحميل فيروس مجاني', // Malicious
      'أرسل كلمة المرور لحسابك', // Phishing
      'موقع ألعاب مجانية مع فيروسات', // Suspicious
    ];
  }

  List<String> getSampleUrls() {
    return [
      'https://malware-site.com/download',
      'https://phishing-bank.net/login',
      'https://google.com',
      'https://youtube.com',
      'https://suspicious-link.net/virus',
    ];
  }
}