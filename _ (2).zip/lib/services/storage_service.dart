import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:_/models/app_settings.dart';
import 'package:_/models/threat_detection.dart';
import 'package:_/models/message.dart';

class StorageService {
  static SharedPreferences? _prefs;

  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  static SharedPreferences get prefs {
    if (_prefs == null) {
      throw Exception('StorageService not initialized');
    }
    return _prefs!;
  }

  // Settings
  static Future<void> saveSettings(AppSettings settings) async {
    await prefs.setString('app_settings', jsonEncode(settings.toJson()));
  }

  static AppSettings getSettings() {
    final settingsJson = prefs.getString('app_settings');
    if (settingsJson == null) {
      return AppSettings();
    }
    return AppSettings.fromJson(jsonDecode(settingsJson));
  }

  // Threat History
  static Future<void> saveThreatDetection(ThreatDetection threat) async {
    final threats = getThreatHistory();
    threats.add(threat);
    
    // Keep only last 100 threats
    if (threats.length > 100) {
      threats.removeRange(0, threats.length - 100);
    }
    
    final threatsJson = threats.map((t) => t.toJson()).toList();
    await prefs.setString('threat_history', jsonEncode(threatsJson));
  }

  static List<ThreatDetection> getThreatHistory() {
    final threatsJson = prefs.getString('threat_history');
    if (threatsJson == null) {
      return [];
    }
    
    final List<dynamic> threatsList = jsonDecode(threatsJson);
    return threatsList.map((json) => ThreatDetection.fromJson(json)).toList();
  }

  // Messages
  static Future<void> saveMessage(ChatMessage message) async {
    final messages = getMessages();
    messages.add(message);
    
    // Keep only last 50 messages
    if (messages.length > 50) {
      messages.removeRange(0, messages.length - 50);
    }
    
    final messagesJson = messages.map((m) => m.toJson()).toList();
    await prefs.setString('messages', jsonEncode(messagesJson));
  }

  static List<ChatMessage> getMessages() {
    final messagesJson = prefs.getString('messages');
    if (messagesJson == null) {
      return [];
    }
    
    final List<dynamic> messagesList = jsonDecode(messagesJson);
    return messagesList.map((json) => ChatMessage.fromJson(json)).toList();
  }

  // Statistics
  static Future<void> incrementThreatCount() async {
    final count = getThreatCount();
    await prefs.setInt('threat_count', count + 1);
  }

  static int getThreatCount() {
    return prefs.getInt('threat_count') ?? 0;
  }

  static int getBlockedThreatsToday() {
    final threats = getThreatHistory();
    final today = DateTime.now();
    return threats.where((threat) => 
      threat.timestamp.day == today.day &&
      threat.timestamp.month == today.month &&
      threat.timestamp.year == today.year &&
      threat.wasBlocked
    ).length;
  }
}