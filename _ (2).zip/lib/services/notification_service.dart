import 'package:flutter/material.dart';
import 'package:_/models/threat_detection.dart';
import 'package:_/services/storage_service.dart';

class ParentNotification {
  final String id;
  final ThreatDetection threat;
  final DateTime sentAt;
  final String message;

  ParentNotification({
    required this.id,
    required this.threat,
    required this.sentAt,
    required this.message,
  });
}

class NotificationService extends ChangeNotifier {
  final List<ParentNotification> _notifications = [];

  List<ParentNotification> get notifications => List.from(_notifications);

  void sendParentAlert(ThreatDetection threat) {
    final settings = StorageService.getSettings();
    
    if (!settings.enableParentNotifications) return;

    final notification = ParentNotification(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      threat: threat,
      sentAt: DateTime.now(),
      message: _generateAlertMessage(threat),
    );

    _notifications.insert(0, notification);
    
    // Keep only last 20 notifications
    if (_notifications.length > 20) {
      _notifications.removeRange(20, _notifications.length);
    }
    
    notifyListeners();
    
    // In a real app, this would send actual notifications
    _simulateParentNotification(notification);
  }

  String _generateAlertMessage(ThreatDetection threat) {
    switch (threat.type) {
      case ThreatType.cyberbullying:
        return 'تنبيه: تم اكتشاف محتوى تنمر في رسالة وحظرها تلقائياً';
      case ThreatType.maliciousMessage:
        return 'تحذير: تم اكتشاف رسالة ضارة وحظرها لحماية طفلك';
      case ThreatType.maliciousWebsite:
        return 'خطر: تم منع طفلك من الوصول لموقع ضار';
      case ThreatType.suspiciousLink:
        return 'تنبيه: تم حظر رابط مشبوه قبل فتحه';
      case ThreatType.inappropriateContent:
        return 'تحذير: تم حظر محتوى غير مناسب';
    }
  }

  void _simulateParentNotification(ParentNotification notification) {
    // In a real app, this would:
    // 1. Send email to parent
    // 2. Send SMS if configured
    // 3. Push notification to parent app
    debugPrint('Parent notification sent: ${notification.message}');
  }

  void clearNotifications() {
    _notifications.clear();
    notifyListeners();
  }

  int get unreadCount => _notifications.length;
}