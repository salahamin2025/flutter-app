import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:_/theme.dart';
import 'package:_/services/security_service.dart';
import 'package:_/services/notification_service.dart';
import 'package:_/services/storage_service.dart';
import 'package:_/screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await StorageService.init();
  runApp(const LittleGuardianApp());
}

class LittleGuardianApp extends StatelessWidget {
  const LittleGuardianApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => SecurityService()),
        ChangeNotifierProvider(create: (context) => NotificationService()),
      ],
      child: MaterialApp(
        title: 'الحارس الصغير',
        debugShowCheckedModeBanner: false,
        theme: lightTheme,
        darkTheme: darkTheme,
        themeMode: ThemeMode.system,
        home: const HomeScreen(),
      ),
    );
  }
}
